##GIT(拉取)

---


[TOC]

----
###GIT
> 分布式版本控制系统
- 记住是谁提交的东西
- 可以保存每个阶段的内容（备份功能）
- 可以实现历史穿越
- github 开源 多端共享
- 团队协作

> 集中式版本控制系统 svn

```
//配置用户名和邮箱
$ git config --global user.name yourname
$ git config --global user.email **@**.com
//查看git配置信息
$ git config --list
```
```
//初始化git（不能嵌套使用git），以某个文件夹作为git管理的目录
$ git init
```
linux命令
```
$ pwd
//打印当前工作目录
$ rm -rf .git //删除整个文件夹需要加 -rf，
//创建文件夹
$ mkdir （文件夹）
//显示所有文件和文件夹
$ ls //list show
//显示所有详细文件和文件夹
$ ls -al
// 改变目录
$ cd 目录 
//创建一个空文件
$ touch xxx

$ vi index.txt
i或者a（插入模式）
esc
shift + ':'
:q  退出
:q! 不保存强制退出
:wq 保存并退出
$ cat 文件名 //查看文件内容
```

git有工作区、暂存区（过渡区）、历史区
svn没有暂存区（过渡区），svn每个文件夹下都有一个.svn文件 git会将需要的文件放在.git下

提交到暂存区
```
$ git add . 或者 git add -A 或者 git add 文件名
```
查看状态，如果是红色表示未添加到暂存区
```
$ git status
```
添加到历史区，第一次提交叫做根提交
```
$ git commit -m"文字"
```
```
$ git commit -a -m "文字"
```
```
//强制推到库中
$ git push origin master --force
```

查看提交历史
```
$ git log
```
比较区的不同
```
//比较工作区和暂存区
$ git diff
//比较工作区和历史区
$ git diff  分支名
//比较暂存区和历史区
$ git diff --cached
```


####版本回退

```
//从暂存区回到工作区
$ git checkout 文件名
```

```
//从暂存区回退到上一次的暂存区内容
$ git reset HEAD 文件名
```
- 从历史区回滚
```
$ git reset --hard 版本ID（可以通过git log查看）
```
```
//（版本回滚后，可以通过此命令查看所有版本ID）
$ git reflog
```

####分支管理
```
//查看分支
$ git branch
//创建分支
$ git branch 分支名
//切换分支 
$ git checkout 分支名
// 删除分支,不能在当前分支上删除当前分支
$ git branch -D 分支名
// 创建并切换分支
$ git checkout -b 分支名
// 合并分支
$ git merge 分支名
```
![Alt text](./1507968484212.png)


```
//见上图
$ git log --graph --oneline
```
> 提交到谁的身上，才会归谁所有，如果再次更改分支上的内容，不提交是无法切换分支的 
> git merge 默认会将分支上所有提交的内容全部合并 

cherry-pick可以用来合并某一个历史
####.gitignore配置

空文件夹默认不会提交，为了能够正常提交，则在空文件夹下新建一个.gitkeep的文件

连接远程仓库
git remote add  origin url
git remote -v
git remote rm orgin
git clone url 名字，如果不写名字，那么默认为origin

settings Collaborators 添加贡献者
在推送时最后先拉取远程的内容，合并后再推送，如果产生冲突，需要先解决冲突

####发布静态网站
- 要求有一个固定的分支 gh-pages
- 将静态内容推送到这个分支上

###SPA（单页应用开发）框架
- 一个单页面应用
###组件
- 把一个复杂的页面拆分成若干个组件，最后再拼成一个完整的页面。这样既减少了逻辑复杂度。
####组件的分类
- 页面级组件（home组件、list组件）
- 基础组件（页面级组件包含基础组件，可复用的组件）

####组件化开发的好处
- 提高开发效率（可以根据组件来分工，实现了所谓的模块化）
- 方便重复使用（相同组件抽离出来）
- 便于协同开发（减少了代码冲突）
- 更容易被管理和维护（某个组件出问题，改某个组件即可）
####组件的使用
- 全局组件（不需要在组件中再次声明）
	+ 写一些插件时可能会需要用到全局组件
- 局部组件（在某个组件中声明的）
	+ 自己写的一些组件，一般都是局部组件

> 1、组件的名字不能使用html标签
> 2、一个组件就是一个对象
> 3、名字规范，组件中的名字，如果中间有大写会自动转化为小写，例：myHello会转换为myhello
> 4、组件模板中只能有一个根节点
> 5、标签中的名字可以转化（短横线转驼峰，大写转小写），一般我们使用时名字保持一致
> 6、组件中的data是一个函数，需要返回一个对象。因为组件之间不应该相互影响，所以data是一个函数，返回一个新对象，来避免相互引用问题
> 7、组件中的数据可以在自己的模板中使用
> 8、在创建实例前先创建组件，然后才能使用组件
> 9、组件里methods中函数的this指向的当前组件的实例。
 > 10、局部组件只能在父级组件中使用，即在哪儿注册的组件，就在哪儿使用。全局组件不需要注册，可以在全局使用
> 11、组件之间相互独立
在Vue构造函数上定义的组件为全局组件
在Vue实例上定义的组件为局部组件
**组件的使用顺序**
> 1、引入组件
> 2、注册组件
> 3、在模板中使用

嵌套的组件可以抽离出来单独来写
```
    let abc = {
        template: '<div>菠菜</div>'
    };
    let child = {
        template: '<div>绿叶蔬菜<abc></abc></div>',
        components: {
            abc
        }
    };
    let parent = {
        template: '<div>蔬菜<child></child></div>',
        components: {
            child
        }
    };
    let vm = new Vue({
        el: '#app',
        components: {
            parent
        }
    })
```

```
<body>
<template id="parent">
    <div>parent<child></child></div>
</template>
<template id="child">
    <div>child</div>
</template>
<script src="node_modules/vue/dist/vue.js"></script>
<script>
    let child = {
        template:'#child'
    };
    let parent = {
        template: '#parent',
        components:{child}
    };
    let vm = new Vue({
        el: '#app',
        template:'<parent></parent>',
        data: {},
        components: {
            parent
        }
    })
</script>
</body>
```
template中的内容会被转换为虚拟DOM
```
<body>
<div id="app"><child :title="msg"></child></div>
<script src="node_modules/vue/dist/vue.js"></script>
<script>
    let vm = new Vue({
        el:'#app',
        data:{
            msg:'老子'
        },
        components:{
            child:{
                template:'<div>儿子 打 {{title}}</div>',
                props:['title'] //拿到title属性
            },
        }
    })
</script>
</body>
```
子组件不能直接修改父组件的数据，这是单向数据流（Prop 是单向绑定的：当父组件的属性变化时，将传导给子组件，但是反过来不会。这是为了防止子组件无意间修改了父组件的状态，来避免应用的数据流变得难以理解。）。如果想子组件修改父组件 的数据，那么可以让子组件传递给父组件，父组件改变后再重新渲染子组件。

**prop验证**
> 我们可以为组件的 prop 指定验证规则。如果传入的数据不符合要求，Vue 会发出警告，但是仍然会执行，`仅仅是发出警告`。这对于开发给他人使用的组件非常有用。
要指定验证规则，需要用对象的形式来定义 prop，而不能用字符串数组
```
Vue.component('example', {
  props: {
    // 基础类型检测 (`null` 指允许任何类型)
    propA: Number,
    // 可能是多种类型
    propB: [String, Number],
    // 必传且是字符串
    propC: {
      type: String,
      required: true
    },
    // 数值且有默认值
    propD: {
      type: Number,
      default: 100
    },
    // 数组/对象的默认值应当由一个工厂函数返回
    propE: {
      type: Object,
      default: function () {
        return { message: 'hello' }
      }
    },
    // 自定义验证函数
    propF: {
      validator: function (value) {
        return value > 10
      }
    }
  }
})
```

ref如果写在组件上，那么就能获取组件的实例
default不能和validate一起使用
this.$emit发布

`组件`就是自定义元素

####全局组件
```
Vue.component(tagName,options);
//所有组件都是基于根实例，且组件只有拥有一个根元素
new Vue({
	el:'#app'
})
```
组件中的data必须是函数，而且返回一个新的对象
因为父组件和子组件的作用域是独立的，互相不能访问，所以需要使用props来接收父组件传递数据给子组件的数据
属性的名字需要转化成驼峰命名法

父组件挂载完成并不一定保证子组件一定渲染完成，所以在mounted中一般会用$nextTick防止无法获取最新的数据

**箭头函数体内的this对象，就是定义时所在的对象，而不是使用时所在的对象**
父传子 属性校验
子传父 自定义事件
平级组件  发布订阅
复杂的 VUEX

slot插槽
别人写好的一个模态框组件，我们来使用， 会先引入进来，传入一些自己的内容，所以绑定的方法都是自己的（即父级的），如果是写在模板上的属性和方法，那么绑定是的模板实例上的。

```
<keep-alive>
<components :is='val'></components
</keep-alive>

//actived钩子函数，不受keep-alive干扰，依然会执行，如果没有keep-alive，则不会执行
当keep-alive移除时调用deactivated(这句话有问题）
当组件在 <keep-alive> 内被切换，它的 activated 和 deactivated 这两个生命周期钩子函数将会被对应执行。
```

###VUE-ROUTER
**路由** ：不同的URL返回不同的结果
VUE的路由：SPA中只有一个首页，切换URL地址显示不同的组件
hash 有#号 ，  history.pushState（）没#号，在开发的时候，页面不存在会产生404，上线时会使用这种方式，可以依赖服务端解决404问题
mode模式，默认模式是hash模式，如果mode:'history'，就是第二种
to动态绑定时可以放对象，tag表示编译后的标签名
```
    let routes=[
        {path:'/',component:home},//path:'/'或path:''配置默认页
        {path:'/home',component:home},
        {path:'/list',component:list},
        {path:'*',component:list} //一定写在最下面，找不到路径时走这个，但是页面的路径还是错误的那个
        {path:'*',redirect:list} //重定向，一般写404
        ];
```

####组件组成
- 模板（结构）：需要vue-template-compiler
- 逻辑（行为）
- 样式 
```
<template>
</template>
<script>
</script>
<style lang="less" scoped>
//lang="less"，指定语言，scoped：样式只在当前文件有效，如果不写scoped那么在全局有效
</style>
```
####webpack 
webpack-dev-server 并不会生成文件，会创建一个服务
npm install vue-template-compiler --save-dev
引入第三方模块时，如果要引入的文件不是默认的，需要把路径写全

```
new Router({
    linkActiveClass: 'link-active',//点击导航时给点击的导航及其父级添加类名。linkExactActiveClass这个是当前选中的那一级导航的样式 
    linkExactActiveClass:'link-exact-active'
    routes: [
        {path: '/home', component: Home},
        {
            path: '/profile',
            component: Profile,
            children: [{path: 'aboutme', component: aboutMe}, {path: 'introduce', component: introduce}]
        },
        {path: '/', component: Home}
    ]
});
```

this.\$route 属性
this.\$router 方法
this.\$router.push('/profile') 路径跳转，将当前的路径放到历史管理中
this.\$router.go(-1) 返回上一页
this.\$router.back() 和this.\$router.go(-1)功能一样
this.\$router.replace('/profile')跳转后不留痕迹
this.$route.params.参数名

##vue-cli 脚手架
- simple
- webpack-simple
- webpack（开发项目时一般用这个）
```
$ npm install vue-cli -g
$ vue init  模板名  项目名
```


####FLEX
**flex布局**
display:flex;
flex:1;
flex-direction: column纵向
justify-content:center 水平居中
align-items:center  垂直居中

跨域请求：
1、cors 服务商配置允许前端跨域
2、jsonp服务端返回一个方法执行：通过js动态创建script标签，script没有跨域限制，所以可以引入外部js。JSONP不支持POST请求
3、iframe跨域，postMessage
4、nginx
5、window.name
6、webpack也可以实现跨域，上线后配置失效

**NODEMON**可以实时监控NODE的改变

```
// exact 精确匹配
<router-link to="/" exact tag="li">
      <i class="iconfont icon-shouye"></i>
      <span>首页</span>
    </router-link>
```

get put delete post；restful风格

VUE-LAZYLOAD，VUE延迟加载插件	
```
import VueLazyload from 'vue-lazyload'

Vue.use(VueLazyload)

// or with options
Vue.use(VueLazyload, {
  preLoad: 1.3,
  error: 'dist/error.png',
  loading: 'dist/loading.gif',
  attempt: 1
})
<img v-lazy="xxx">
```

webpack 2+ 提供，分开打包，路由懒加载

**webpack配置文件**
```
let path = require('path');
let HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
    entry: './src/index.js',
    output: { //输出的配置项
        path: path.resolve('build'),//输出的目录
        filename: 'bundle.js',//输出的文件名
    },
    module: {
        rules: [
            {test: /\.js$/, use: 'babel-loader', exclude: /node_modules/},
            {test: /\.less$/, use: ["style-loader", "css-loader", "less-loader"], exclude: /node_modules/},
            {test: /\.(jpg|png|gif|svg)$/, use: "url-loader", exclude: /node_modules/},
        ]
    },
    devtool: 'cheap-module-source-map',//在出错的时候可以提示在源文件具体的代码行数，而非bundle.js行数
    plugins: [
        new HtmlWebpackPlugin({
            template: 'index.html'
        })
    ]
};
```